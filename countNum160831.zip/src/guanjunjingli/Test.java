package guanjunjingli;

import java.io.File;
import java.io.IOException;

import static guanjunjingli.Utils.tiqu;

/**
 * Created by Administrator on 2016/8/16.
 */
public class Test {

    public static void main(String[] args) throws IOException {
        tiqu(new File("D:\\工作目录\\guanjun冠军经理\\冠军经理17\\assets\\packres-android_core.png"));
    }
}
